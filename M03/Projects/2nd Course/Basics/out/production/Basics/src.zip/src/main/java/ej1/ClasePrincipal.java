/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej1;

/**
 *
 * @author victor
 */
public class ClasePrincipal {
    
    public static void main (String []args){
        
        /*
         * 1  Complete the code whith the necessary lines to compile the program
         */
        unObjetoClassOne.escribir("Hello world");
        
        
    }
    
}

/*
 *  2 What is the difference between declaring ClassOne at line 13 or  at line 16?
 */

/*
 *  3 Declare a private atribute for ClassOne.  It must be an ArrayList of ClassTwo
 */

/*
 *  4 Initialize the ClassOne attribute adding three elemens of ClassTwo
 */

/*
 *  5 Implement a method to show all the elemens stored in the new attribute that you have initilized
 */

/*
 *  6 Implementt a method to show the second element of the new attribute
 */