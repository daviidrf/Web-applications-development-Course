Generalitat de Catalunya
Departament d’Educació
INS Provençana
PRÀCTICA PUNTUABLE (DAW-2)
Pt2- UF1
Continuem la Pt1 que heu fet.
Exercici 1.- (1.5 punts)
El primer que haureu de fer serà canviar el sistema dels arrays associatius que heu
fet servir a la Pt1 per a gestionar les enquestes. Ara heu de fer que tot funcioni
correctament però amb fitxers. 
SUGGERIMENT:
Per exemple, podeu tenir una sèrie de fitxers de nom els codis correctes. D’aquesta manera si
existeix un fitxer amb el codi sol·licitat en el formulari, l’obriu i llegiu el títol de l’enquesta, les
preguntes, les possibles respostes i les respostes correctes. Un cop llegit ja podeu fer servir
aquesta informació per a generar l’enquesta (tal i com havíeu fet a la Pt1)
Exercici 2.- (4 punts)
Login i Registre: els links del menú de la Pt1 ara sí que funcionaran.
REGISTRE: (2.5 punts)
Si cliquem a l’opció de menú de Registre, apareixerà just a sota del menú un
formulari on es demanaran el nom, els cognoms, l’email, la data de naixement,
l’usuari d’entrada, el password i quin tipus de preferències té (checkbox que
demani alguna cosa sobre aficions) Tots els camps s’hauran de validar:
- nom, cognoms → només lletres
- email → de tipus correu electrònic
- data → de tipus data i que sigui correcta
- usuari → lletres i/o números i/o – i/o _
- password → mínim de 8 amb lletres majúscules i minúscules i números
- aficions → que cliqui mínim una
Si no passa la validació, se li diu on estan els errors.
Si passa la validació, tots aquests camps es guardaran a l’arxiu de nom users.txt.
Cada línia d’aquest arxiu correspondrà a un usuari diferent. Els camps dels
registres es guardaran amb el format següent:
usuari:password:email:nom:cognoms:data:aficions separades per comes:rol:
El camp rol serà el tipus d’usuari que entra a la web. Si es registra, tal i com es
descriu aquí, el rol sempre serà el de basic.
Ara bé, existiran ja a l’arxiu 1 o 2 usuaris amb el rol admin.
 CURS 2021-2022 1/3
Generalitat de Catalunya
Departament d’Educació
INS Provençana
PRÀCTICA PUNTUABLE (DAW-2)
LOGIN: (1.5 punts)
Si cliquem a l’opció de menú de Login, apareixerà just a sota del menú un
formulari de validació per poder entrar.
Si l’usuari i el password estan a l’arxiu users.txt, llavors entrarem al que se’ns
diu a l’exercici 3.
Exercici 3.- (4.5 punts)
Compte que els usuaris han de passar obligatòriament pel formulari de login
abans d’arribar aquí (control amb sessió/ns)
Un cop els usuaris s’hagin validat correctament passaran a tenir funcionalitats
diferents i l’aspecte de la web canviarà. Pot canviar, el color de fons, el tipus de
lletra, el color de fons del menú... D’aquesta manera distingirem visualment si
estem davant d’un usuari amb rol basic o admin.
(2 punts)
Si l’usuari té el rol basic, aquest usuari podrà navegar lliurament per la nostra
web com abans, però ara:
- Les opcions del menú canviaran: només tindrà les opcions de Home, Quiz
(per a fer les enquestes) i Logout (per sortit)
- Ara, com que està loguejat a la web es quedaran enregistrats tots els seus
resultats en un fitxer de nom results.txt . És a dir, quan entri pot veure el
mateix que a la Pt1 però se li guarden de manera persistent el seu nom
d’usuari, els resultats obtinguts (enquestes contestades, errors fets i quants
punts he obtingut -cada resposta correcta suma 10 punts-) 
Podeu guardar en un fitxer tot això que s’acaba de comentar quan
estigui a la pantalla que conté el botó de generar el PDF, afegint un
nou botó ‘Guardar’.
(2.5 punts)
Si l’usuari té el rol d’ admin:
- Les opcions del menú canviaran: només tindrà les opcions Home, Create
(per a crear les enquestes) i Logout (per sortit)
- Opció Create: li sortirà un formulari ple d’inputs de tipus text en què se li
demanarà: el codi de l’enquesta, el títol, les preguntes (sempre 3) que
contindrà i a sota de cada pregunta les 3 possibles respostes i la solució
 CURS 2021-2022 2/3
Generalitat de Catalunya
Departament d’Educació
INS Provençana
PRÀCTICA PUNTUABLE (DAW-2)
bona. Per no complicar-ho molt fixeu-vos que sempre seran enquestes de 3
preguntes amb 3 possibles respostes.
- Un cop ompli tots els inputs, podrà clicar un botó d’enviament per a
guardar l’enquesta en un fitxer. Abans però de fer aquesta inserció, se li
validarà que el codi tingui la forma correcta (i que ja es va validar en un
altre formulari a la Pt1). L’enquesta quedarà guardada a l’arxiu /arxius que
heu fet servir a l’Exercici 1 d’aquesta mateixa Pt2.
Criteris de correcció 
 Els exercicis que donin errors d’interpretació o no es puguin executar no seran
avaluats. 
 La funcionalitat ha de ser adient a la demanda de l’enunciat de l’exercici. Evitar
missatges per pantalla innecessaris. 
 El tractament d'errors ha de ser adequat, de manera que si es produeixen hauria
d'informar-se a l'usuari del tipus d'error produït. 
 Cuidar l'estructura dels nostres programes i la documentació del codi.
 La presentació final dels exercicis han de tenir un resultat professional i, per tant,
es demana la utilització de CSS personalitzats o frameworks com Bootstrap. 
Avaluació 
 Aquesta pràctica Pt1 representa el 25% del total de la puntuació de la UF1. 
 La puntuació de cadascun dels apartats s’indica al contingut de la pràctica.
 No es permet el lliurament d’aquesta pràctica fora del termini establert a la tasca
del Moodle. 
 CURS 2021-2022 3/3