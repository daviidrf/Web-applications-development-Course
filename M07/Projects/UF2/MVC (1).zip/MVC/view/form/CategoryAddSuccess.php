<div class="container-fluid">
  <p>Category added</p>
</div>
