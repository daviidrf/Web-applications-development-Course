/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model;

import java.util.Date;

/**
 *
 * @author David
 */
public class Player {
    
    private long id;
    private String name;
    private String surname;
    private Date birthdate;
    private double salary;
    private long idTeam;
}
