package cat.proven.exceptions;

/**
 *
 * @author David
 */
public class ParameterNull extends Exception{
    
     public ParameterNull(String message) {
        super(message);
    }
}
