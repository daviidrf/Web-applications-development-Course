/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model;

/**
 *
 * @author David
 */
public class Team {
    
    private long id;
    private String name;
    private String coach;
    private String category;
    private double budget;
}
