package cat.proven.exceptions;

/**
 *
 * @author David
 */
public class DuplicateException extends Exception{

    public DuplicateException(String message) {
        super(message);
    }
    
    
}
